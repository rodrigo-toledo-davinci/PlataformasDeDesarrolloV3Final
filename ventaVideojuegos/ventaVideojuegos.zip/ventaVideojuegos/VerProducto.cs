﻿using ventaVideojuegos.Modelo;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ventaVideojuegos
{
    public partial class VerProducto : Form
    {

        ListaProducto listaProds = ControladorProductos.ListaProducto;
        DataTable tabla;


        public VerProducto()
        {
            InitializeComponent();
            IniciarTabla();
            LlenarTabla();  
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            Form1 formNew = FormsController.Form1;
            formNew.Show();
            this.Hide();
        }

        private void Grilla_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void IniciarTabla()
        {
            tabla = new DataTable();
            tabla.Columns.Add("Nombre");
            tabla.Columns.Add("Precio");
            tabla.Columns.Add("Stock");
            Grilla.DataSource = tabla;
        }

        private void LlenarTabla()
        {
            foreach(var item in listaProds.Consultar())
            {
                DataRow fila = tabla.NewRow();
                fila["Nombre"] = item.Nombre;
                fila["Precio"] = item.Precio;
                fila["Stock"] = item.Stock;
                tabla.Rows.Add(fila);
            }
        }
    }
}
