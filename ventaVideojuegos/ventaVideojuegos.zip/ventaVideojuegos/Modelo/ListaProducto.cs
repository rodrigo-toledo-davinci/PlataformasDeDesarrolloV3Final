﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ventaVideojuegos.Modelo
{
    public class ListaProducto
    {

        List<Producto> lista = new List<Producto>();
        
        public void GuardarEnInstancia(Producto prod)
        {
            lista.Add(prod);
        }

        public void GuardarEnMemoria(Producto prod)
        {
            StreamWriter archivo = new StreamWriter("productos.txt");
            archivo.WriteLine(prod.Nombre);
            archivo.WriteLine(prod.Precio);
            archivo.WriteLine(prod.Stock);
            archivo.Close();
        }

        public List<Producto> Consultar ()
        {
            return lista;   
        }

    }
}
