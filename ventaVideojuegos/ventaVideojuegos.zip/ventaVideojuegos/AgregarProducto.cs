﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ventaVideojuegos.Modelo;

namespace ventaVideojuegos
{
    public partial class AgregarProducto : Form
    {
        public AgregarProducto()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            RegresarForm1();
        }

        private void RegresarForm1()
        {
            Form1 formNew = FormsController.Form1;
            formNew.Show();
            this.Hide();
        }

        private void GuardarProducto()
        {
            Producto prod = new Producto()
            {
                Nombre = txtNombre.Text,
                Precio = int.Parse(txtPrecio.Text),
                Stock = int.Parse(txtStock.Text)
            };

            ListaProducto lista = ControladorProductos.ListaProducto;
            lista.GuardarEnInstancia(prod);
            lista.GuardarEnMemoria(prod);

        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            GuardarProducto();
            RegresarForm1();
        }

        private void txtPrecio_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
